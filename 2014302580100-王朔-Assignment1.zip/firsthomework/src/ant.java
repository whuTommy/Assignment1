import java.io.File;

public class ant {

	public static void main(String[] args)
	{
		String urlname="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2029%202015%2019:26:46%20GMT+0800";
		String filepath="test.html";
	    
		HttpRequest request = HttpRequest.get(urlname).header("Cookie","JSESSIONID=D4ADE44BE51055E717EB9E3BAD147671.tomcat2");
		
		request.receive(new File(filepath));

	}

	
}
