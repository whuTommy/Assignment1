import java.io.File;

public class Image {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2030%202015%2023:37:05%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
	
   
		HttpRequest response=HttpRequest.get(url);//���÷�װ����
		response.header("Cookie","JSESSIONID=A24A49BB2B2D3BCE2DF8C681E4287D00.tomcat2");
		String fName="MyGradeImge.html";
		
        response.receive(new File(fName));
        System.out.println("ok");

}

}