//2015.9.29
//LiYuanQing-2014302580322
//use JDK

import java.io.File;

public class GradeList {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HttpRequest glist = HttpRequest.get("http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2029%202015%2015:45:56%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)");//Establish connection
		glist.header("Cookie","JSESSIONID=84D899BAEF0E11E18F456966FBF0C069.tomcat2");//cookie  Simulated landing
		if (glist.ok())
			glist.receive(new File("grade.html"));//Climb up to grade.html
	}


}
