package assignment1;
import java.io.*;
public class Score {
	public static void main(String[] args){
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2029%202015%2001:59:39%20GMT+0800%20(CST)";
		HttpRequest Request = new HttpRequest(url,"GET");
		Request.header("Cookie","JSESSIONID=7E48183009E145607AB617B156ACD73D.tomcat2");
		System.out.println("get it");
	
		

		if(Request.ok()){
		Request.receive(new File("MyScore.html"));
		System.out.println("save");
		}
		
	}
}


