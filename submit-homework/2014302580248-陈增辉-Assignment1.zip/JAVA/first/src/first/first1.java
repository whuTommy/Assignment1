package first;
import java.io.File;
import first.HttpRequest.HttpRequest;
public class first1 {
       public static void main(String[] args){
    	   //�����ҵ��ɼ�����Ӧ����
          String urlString = "http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2021%202015%2021:15:43%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
          //Ȼ����resourse���ҵ�Cookie
          String cookies = "JSESSIONID=578730C4507DC35BC69AD9DAB5D77E42.tomcat2";
          //�ٶ����ļ���
          String filePath = "test2.html";
          
          HttpRequest response = HttpRequest.get(urlString).header("Cookie", cookies);
          response.receive(new File(filePath));
       }
}
