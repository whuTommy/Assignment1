import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;

public class GetGrade {
	public static void main(String args[]){            //method
		   
		   String url ="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2024%202015%2011:37:49%20GMT+0800%20(CST)";//string url
		   String gname = "grade"+".html";             //file name
		 	   HttpRequest response = HttpRequest.get(url);			 	   	//get url
		 	               response.header("Cookie", "JSESSIONID=AECD895A132B87AD776F0CDB666FD050.tomcat2");		 	  
		    			   response.receive(new File(gname));		 //receive File   				    			    	
		    	System.out.printf("get");		   
	   }
}
