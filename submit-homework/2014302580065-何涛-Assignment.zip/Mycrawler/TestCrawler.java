import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import com.github.kevinsawicki.http.HttpRequest;
public class TestCrawler {
   public static void main(String[] args) throws IOException {
		String urlString="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sat%20Sep%2026%202015%2020:00:31%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		
        String filePath = "mygradeRecord.html";
		
		URL url=new URL(urlString);
		
		URLConnection connection=url.openConnection();
		
		InputStream is=connection.getInputStream();
		
		FileOutputStream fos=new FileOutputStream(filePath);
	
		byte[]buffer=new byte[1024];
	    while(is.read(buffer)!=-1){
			fos.write(buffer);
		}
	    //ʹ��cookieģ���¼
	    HttpRequest GRADEreq = HttpRequest.get(urlString).header("Cookie","JSESSIONID=C8B509238ACF749DF6151C0077C5535D.tomcat2");
		 GRADEreq.receive(new File("mygradeRecord.html"));
	    is.close();
		
		fos.close();
		
	}

}
