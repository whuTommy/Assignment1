import java.io.File;
public class ImageCrawler{
	
    public static void main(String args[])
      {
          String url= "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Fri%20Sep%2025%202015%2019:10:05%20GMT+0800%20(CST)";
                       
        	 HttpRequest response = HttpRequest.get(url).header("Cookie","JSESSIONID=3768B945337339DFC66E0046EDD2DCEC.tomcat2");
        	 String fName = "score"+".html";
             if(response.ok()){
        		  response.receive(new File(fName));
        	  }
      }
}