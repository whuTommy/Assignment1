/*2014302580178
 * �޾���
 * 15-9-27
 * ����
 */

/* Methods explanation.
 * 1.GetImage��get the  CAPTCHAimage from educational administration system website.
 * 2.GetCookie:get the cookie of image to login the website
 * 
 */
package assignment;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.*;

import com.github.kevinsawicki.http.*;

public class Main {
	public static void main(String[] args) {

		// HttpRequest.get("http://210.42.121.132/").receive(output);
		// base information init
		String ImgUrl = "http://210.42.121.132/servlet/GenImg";
		// test 100 image
		// GetImage(ImgUrl);
		String CourserUrl = "http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
		String LoginUrl = "http://210.42.121.132/servlet/Login";
		Scanner input = new Scanner(System.in);
		System.out.println("please enter your ID:");
		String StuId = input.nextLine();
		System.out.println("please enter your pw:");
		String PassWord = input.nextLine();
		String cookies = GetCookie(ImgUrl);
		// System.out.println(cookies);
		System.out.println("please enter your image key(the_enter_one.png)");
		String captcha = input.nextLine();
		// base information init

		// put data in map
		Map<String, String> data = new HashMap<String, String>();
		data.put("id", StuId);
		data.put("pwd", PassWord);
		data.put("xdvfb", captcha);
		HttpRequest login = HttpRequest.post(LoginUrl)
				.header("Cookie", cookies).form(data).followRedirects(false);
		System.out.println(login.body());// show you the problem or keep
											// simulation of login
		File output = new File("out.html");
		HttpRequest.get(CourserUrl).header("Cookie", cookies).receive(output);
		// System.out.println(cookies);

	}

	public static void GetImage(String url) {
		// GetImage��get the CAPTCHAimage from educational administration system
		// website.

		for (int i = 0; i < 100; i++) {
			HttpRequest response = HttpRequest.get(url);
			String FileName = "no." + Integer.toString(i) + ".png";
			if (response.ok()) {
				response.receive(new File(FileName));
				// System.out.print(i);
			}
		}
	}

	public static String GetCookie(String url) {
		// get the cookie by the captcha image
		HttpRequest response = HttpRequest.get(url);
		if (response.ok()) {
			/*
			 * we can output headers find that {Transfer-Encoding=[chunked],
			 * null=[HTTP/1.1 200 OK], Server=[nginx/1.2.1],
			 * Connection=[keep-alive],
			 * Set-Cookie=[JSESSIONID=A695B6EC76986E05F87AB2D66FD49BE9.tomcat2;
			 * Path=/], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], Date=[Sun, 27
			 * Sep 2015 06:16:50 GMT], Content-Type=[image/jpeg]}
			 */
			String cookies = response.headers().get("Set-Cookie").get(0)
					.split(";")[0];
			// System.out.println(cookies);
			String FileName = "the_enter_one.png";
			// System.out.println(cookies);
			response.receive(new File(FileName));
			// System.out.println(cookies);
			return cookies;
		}
		return " ";
	}
}
