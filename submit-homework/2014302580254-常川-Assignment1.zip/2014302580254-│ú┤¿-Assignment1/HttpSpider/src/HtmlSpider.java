
import java.io.File;
import HttpRequest.HttpRequest;

public class HtmlSpider { 
    public static void main(String argsp[])
    { 
    	String url = "http://210.42.121.133/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sat%20Sep%2026%202015%2011:47:51%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4";	
        //Getting the HTML code and setting cookie to make it executable in any computer
    	HttpRequest response =HttpRequest.get(url).header("Cookie","JSESSIONID=59FC01067F93018EC834A0BB2871C9D9.tomcat2");
        //Output the HTML code to HTML files
    	String fName = "D:/OutPut/MyGrade.html"; 
    	//determining whether the program is executed
    	if(response.ok())
    	{
    		response.receive(new File(fName));
    		System.out.println("Output Successfully");
    	}
    }
}
