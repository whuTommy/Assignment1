package test2;

import java.io.File;

public class test {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		String url =  "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
		HttpRequest response = HttpRequest.get(url).header("Cookie","JSESSIONID=24A24B6816673F1E51DCC4D9560CAD3E.tomcat2");
		 response.receive(new File("Huxiangrui.html"));
	}
	
}
