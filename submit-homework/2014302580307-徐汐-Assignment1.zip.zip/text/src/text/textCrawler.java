package text;
import java.io.File;

public class textCrawler {
	public static void main(String args[]){
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Fri%20Sep%2025%202015%2023:04:30%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4";//��ȡURL
		HttpRequest response = HttpRequest.get(url).header("cookie","JSESSIONID=1BD38C4308A8D576240F6ECB78E8D648.tomcat2");//��ȡcookie
		response.receive(new File("score.html"));//����html
	    System.out.println("ok");//��ʾ�ɹ�
	}
}
