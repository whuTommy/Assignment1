package Assignment;
import java.io.File;
public class Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String strURL ="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2030%202015%2012:38:19%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		String filePath="Assignment1.html";
		
		HttpRequest response = HttpRequest.get(strURL);
		response.header("Cookie","JSESSIONID=E6C5C30654DA6A8F1F37286B1189158E.tomcat2");
		response.receive(new File(filePath));
		
	}

}
