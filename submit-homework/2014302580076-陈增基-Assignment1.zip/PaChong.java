package firet;


import java.io.File;

public class PaChong {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
	//ȡַ
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2027%202015%2015:56:00%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
	//��ַ
		HttpRequest httpRequest=HttpRequest.get(url).header("Cookie","JSESSIONID=C5ACAE8401A99D0B32511261C3D93743.tomcat2");
	//��ȡ		
	if(httpRequest.ok()){
		httpRequest.receive(new File("ChengJiDan.html"));
		System.out.println("ok");
		
	}
	}

}
