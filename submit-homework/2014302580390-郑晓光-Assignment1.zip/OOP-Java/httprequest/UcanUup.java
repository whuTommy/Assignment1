package httprequest;

import java.io.File;

public class UcanUup {
	public static void main(String[] args){
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2027%202015%2017:33:37%20GMT+0800";
	    HttpRequest request = HttpRequest.get(url);
	    request.header("Cookie","JSESSIONID=972F7AA40D0A66C65126A6C4848A98EB.tomcat2");
	    request.receive(new File("score.html"));
}
}


