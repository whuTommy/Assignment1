package assignment1;
import java.io.*;
public class GradeList {
	public static void main(String[] args){
		String url = "http://210.42.121.133/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2030%202015%2021:27:06%20GMT+0800";//��ȡURL
		HttpRequest response = HttpRequest.get(url).header("cookie","JSESSIONID=2A14D09B9C95E06DF2C4B8D99D15A6AD.tomcat2");//��ȡcookie
		System.out.println("succeed!");
		if(response.ok()){
		response.receive(new File("MyGradeList.html"));
		System.out.println("save");
		}
	}
}


















