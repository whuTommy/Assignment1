package zxy;

import java.io.File;


public class ImageCopy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2012:34:45%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		HttpRequest request=HttpRequest.get(url);
		request.header("Cookie", "JSESSIONID=492A0FDE3E0B0C527384207A9DB99559.tomcat2");
		String fName="myGradeTable.html";
		request.receive(new File(fName));
		
			
		
	}


	}


