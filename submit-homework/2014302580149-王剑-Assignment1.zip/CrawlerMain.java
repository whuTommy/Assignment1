package crawler;

import java.io.*;

public class CrawlerMain {
	public static void main(String[] args)
	{
		//The following codes can get the result from website http://open.163.com/ of reseaching Computer Graphics
		//File output = new File("get.html");
		//HttpRequest.get("http://c.open.163.com/search/search.htm?query=Computer+Graphics&enc=%E2%84%A2#/search/all").receive(output);
		
		//Get the url and cookie of the website
		HttpRequest StrResponce=HttpRequest.get("http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2028%202015%2020:39:00%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)");
		StrResponce.header("Cookie","JSESSIONID=9DB0B051F6DD19F5FECCEF9D903C4BC7.tomcat2");
		String HtmlText=StrResponce.body();
		//Output the content
		System.out.println(HtmlText);
		try(
				FileOutputStream MyOut=new FileOutputStream("MyHtml.html");
			)
			{
				MyOut.write(HtmlText.getBytes("utf-8"));
			}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		
	}
}
