import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Spider1 {
	static String RegexString(String targetStr, String patternStr) {
		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(targetStr);
		if (matcher.find()) {
			return matcher.group(1);
			}
		return "Nothing";
		}
	public static void main(String[] args) throws IOException{
		String url="http://210.42.121.241/";
		String result="";
		File file=new File("F:/index.html");
		FileWriter fr=new FileWriter(file);
		BufferedReader in=null;
		try{
			URL webURL=new URL(url);
			URLConnection con=webURL.openConnection();
			con.connect();
			in=new BufferedReader(new InputStreamReader(con.getInputStream()));
			String line;
			while((line=in.readLine())!=null){
				result=result+line+"\n";
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				if (in != null) {
					in.close();
					}
				}
			catch(Exception e2) {
				e2.printStackTrace();
			}
		System.out.println(result);
		System.out.println(RegexString(result,"src=\"(.+?)\""));
		fr.write(result);
		fr.close();
		}
	}
}
