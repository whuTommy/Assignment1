import java.util.regex.*;

public class Regex{
	public static void main(String[] args){
		Pattern pattern=Pattern.compile("(\\d{3})([a-zA-Z]{3})");
		Matcher matcher=pattern.matcher("123asd456fgh");
		while(matcher.find()){
			System.out.println(matcher.group(2));
			}
		}
}