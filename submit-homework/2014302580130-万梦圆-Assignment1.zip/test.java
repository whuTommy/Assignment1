package com.github.kevinsawicki.http;

import java.io.File;

public class test {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		String url =  "http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%2019:43:47%20UTC+0800%202015"; 						
		HttpRequest response = HttpRequest.get(url).header("Cookie", "JSESSIONID=93717B832C20EBDA8446334952133708.tomcat2");
		String fName = "test.html";
		if(response.ok()){
			response.receive(new File(fName));
			}
		}
}

