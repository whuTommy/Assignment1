import java.io.File;
public class Image 
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2023%202015%2016:42:15%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		String fName ="image.html";
		HttpRequest response=HttpRequest.post(url).header("cookie","JSESSIONID=C099FD0843394D6816B06140CDE02584.tomcat2");
		response.receive(new File(fName));
			
	}	
}
