import java.io.File;

public class BilibiliCrawler {
	public static void main(String[] args) {
		// get URL
		String gradeUrl1="http://member.bilibili.com/";
		String gradeUrl2="http://static.hdslb.com/css/base.css";
		String gradeUrl3="http://static.hdslb.com/css/member_v2.css";
		String gradeUrl4="http://static.hdslb.com/images/jquery-ui/smoothness/jquery-ui.css";
		String gradeUrl5="http://static.hdslb.com/css/redactor-8.2.4.css";
		//�������󲢸�ֵ
		HttpRequest response1=HttpRequest.get(gradeUrl1);
		HttpRequest response2=HttpRequest.get(gradeUrl2);
		HttpRequest response3=HttpRequest.get(gradeUrl3);
		HttpRequest response4=HttpRequest.get(gradeUrl4);
		HttpRequest response5=HttpRequest.get(gradeUrl5);
		//�޸�header��ֵ
		response1.header("Cookie","_cnt_pm=0; _cnt_notify=86; sid=77r0znoc; pgv_pvi=9229187072; _cnt_dyn=null; DedeID=864458; DedeUserID=3199441; DedeUserID__ckMd5=b0ffedec818721ea; SESSDATA=d29855ff%2C1443711646%2C8054fad6; _dfcaptcha=60b2595b7759d3ebda5b1d65f0f4c897; LIVE_LOGIN_DATA=3e4329311cee6542b046a0f882875ac140c8a522; LIVE_LOGIN_DATA__ckMd5=939ed87089c36fd5; pgv_si=s7513899008; fts=1443108384; uTZ=-480; member_v2=1");
		//�ļ�����
		String fName1="bilibili.html";
		String fName2="first.css";
		String fName3="second.css";
		String fName4="third.css";
		String fName5="fourth.css";
		//�жϲ�����Ŀ���ļ�
		if(response1.ok())
		{
			response1.receive(new File(fName1));
		}
		if(response2.ok())
		{
			response2.receive(new File(fName2));
		}
		if(response3.ok())
		{
			response3.receive(new File(fName3));
		}
		if(response4.ok())
		{
			response4.receive(new File(fName4));
		}
		if(response5.ok())
		{
			response5.receive(new File(fName5));
		}
	}

}
