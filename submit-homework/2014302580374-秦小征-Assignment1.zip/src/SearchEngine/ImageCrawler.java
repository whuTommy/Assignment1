package SearchEngine;

import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;

public class ImageCrawler {

	public static void main(String[] args) {
		
		/*
		HttpRequest response = HttpRequest.get("http://210.42.121.241//servlet/Svlt_QueryStuScore?year=0&amp;term=&amp;learnType=&amp;scoreFlag=0&amp;t=Tue Sep 22 2015 18:09:15 GMT+0800").header("Cookie", "BDB23C05DD4ABF2FE1F7F1A5C5747510.tomcat2");
		response.receive(new File("./output/main.html"));
		*/
		
		 String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2019:03:49%20GMT+0800%20(CST)";
		 String fName = "./output/servlet/main.html";
		 HttpRequest response = HttpRequest.get(url);
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File(fName));
		
		 response  = HttpRequest.get("http://210.42.121.134/css/tab.css?v=2.002");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/css/tab.css"));
		 response = HttpRequest.get("http://210.42.121.134/css/style_common.css?v=2.002");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/css/style.css"));
		 response = HttpRequest.get("http://210.42.121.134/js/jquery.tools.min.js");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/js/jquery.tools.min.js"));
		 response = HttpRequest.get("http://210.42.121.134/js/table.js?v=2.002");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/js/table.js"));
		 response = HttpRequest.get("http://210.42.121.134/images/round_corner_up_right.png");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/images/round_corner_up_right.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/button_bg.png");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/images/button_bg.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/round_corner_left.png");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/images/round_corner_left.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/round_corner_right.png");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/images/round_corner_right.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/btn_bg.png");
		 response.header("Cookie", "JSESSIONID=5C048493ACF01AEDBFDFB7F82544D40C.tomcat2");
		 response.receive(new File("./output/images/btn_bg.png"));
		/*HttpRequest response = HttpRequest.get(url).header("Cookie", "JSESSIONID=96A98039A77CB4B256BEAF46ABA5DFD1.tomcat2");
		String contentType = HttpRequest.get("http://210.42.121.134//servlet/Svlt_QueryStuScore?year=0&amp;term=&amp;learnType=&amp;scoreFlag=0&amp;t=Tue Sep 22 2015 18:09:15 GMT+0800")
                //.accept("output/json") //Sets request header
                .contentType(); //Gets response header
		//System.out.println("Response content type was " + contentType);
		
		/*
		 response = HttpRequest.get("http://210.42.121.134/css/tab.css?v=2.002");
		response.receive(new File("./output/css/tab.css"));
		 response = HttpRequest.get("http://210.42.121.134/css/style_common.css?v=2.002");
		response.receive(new File("./output/css/style_common.css"));
		 response = HttpRequest.get("http://210.42.121.134/js/jquery.tools.min.js");
		response.receive(new File("./output/js/jquery.tools.min.js"));
		response = HttpRequest.get("http://210.42.121.134/js/table.js?v=2.002");
		response.receive(new File("./output/js/table.js"));
		 response = HttpRequest.get("http://210.42.121.134/images/boy_bg.png");
		response.receive(new File("./output/images/boy_bg.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/round_corner_up_right.png");
		response.receive(new File("./output/images/round_corner_up_right.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/round_corner_left.png");
		response.receive(new File("./output/images/round_corner_left.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/round_corner_right.png");
		response.receive(new File("./output/images/round_corner_right.png"));
		 response = HttpRequest.get("http://210.42.121.134/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2017:29:47%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)");
		response.receive(new File("./output/servlet/main.html"));
	response = HttpRequest.get("http://210.42.121.134/css/style.css?v=2.002");
		response.receive(new File("./output/css/style.css"));
		
		 response = HttpRequest.get("http://210.42.121.134/js/jquery.tools.min.js");
		response.receive(new File("./output/js/jquery.tools.min.js"));
		 response = HttpRequest.get("http://210.42.121.134/js/table.js?v=2.002");
		response.receive(new File("./output/js/table.js"));
		 response = HttpRequest.get("http://210.42.121.134/images/btn_bg.png");
		response.receive(new File("./output/images/btn_bg.png"));
		 response = HttpRequest.get("http://210.42.121.134/images/button_bg.png");
		response.receive(new File("./output/images/button_bg.png"));
		 response = HttpRequest.get("http://210.42.121.134/css/tab.css?v=2.002");
		response.receive(new File("./output/css/tab.css"));
		*/
		System.out.printf("end");
		
		return;
	}

}
