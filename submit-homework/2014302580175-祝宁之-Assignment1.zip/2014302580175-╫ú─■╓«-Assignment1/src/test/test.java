package test;
import java.io.File;


public class test {
public static void main(String args[]){
	String urlstr="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2012:33:38%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
	String filepath="test.html";
	HttpRequest response=HttpRequest.post(urlstr).header("Cookie","JSESSIONID=0646C31ADF2518896FC2890D6A4CD664.tomcat2");
	response.receive( new  File (filepath));
	
	
}
}
