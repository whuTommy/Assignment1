import java.io.File;


public class pcc {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String urlString = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2016:44:49%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		String filePath="pcc.html";


		HttpRequest response =HttpRequest.get(urlString).header("Cookie","JSESSIONID=C67DEF7698E49BBD0824FDC6F48D3C41.tomcat2");;
		response.receive(new File(filePath));
	}

}

