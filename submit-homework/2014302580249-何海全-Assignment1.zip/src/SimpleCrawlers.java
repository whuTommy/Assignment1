/*
import java.io.FileOutputStream;

public class SimpleCrawlers {
	public static void main(String args[]) throws IOException{
		String urlString = "http://210.42.121.132/";
		String filePath = "aa.txt";
		URL url = new URL(urlString);
		URLConnection connection = url.openConnection();
		InputStream is = connection.getInputStream();
		FileOutputStream fos = new FileOutputStream(filePath); 
		byte[] buffer = new byte[1024];
		while(is.read( != -1)){
			fos.write(buffer);
		};
		is.close();
		fos.close();
	} 
}
*/