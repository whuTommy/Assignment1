//import java.io.File;
//import java.io.IOException;
//JSESSIONID=AC35F42539AEC260DA5EF9B108C97A8B.tomcat2;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.*;
public class BetterCrawler {
	public static void main(String args[]) throws UnsupportedEncodingException, FileNotFoundException{
		/*
		String response = HttpRequest.get("http://210.42.121.133/").header("Set-Cookie"); //Sets request header    
		System.out.println("Response was: "+response);
		String response = HttpRequest.get("http://210.42.121.133/stu/stu_index.jsp").header("Cookie", "JSESSIONID=06987FBED14D670D3D373C8E5514DCC8.tomcat2")
		.body();
		*/
		
		//HttpRequest.post("http://210.42.121.133/servlet/Login").send("id=2014302580249&pwd=19960324&xdvfb=JMNV").code();
	
		String filePath = "Score.html";
		Date t = new Date();
		
		//Sun Sep 20 2015 22:49:04 GMT+0800 (�й���׼ʱ��)(javascript)
		//Sun Sep 20 22:56:00 CST 2015
		//String jsStyleDate = 
		String javaDate = t.toString();
		//��java������ת��Ϊjavascript����
		javaDate = javaDate.substring(0,javaDate.length() - 8)+ "GMT+0800 (�й���׼ʱ��)";
		String url = "http://210.42.121.133/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=" + URLEncoder.encode(javaDate, "UTF-8");
		String response = HttpRequest.get(url).header("Cookie", "JSESSIONID=B2C07C45CD174BEC77479E65E99BE457.tomcat2")
		.body();
		PrintWriter out = new PrintWriter(filePath);
		out.println(response);
		out.close();
		
	} 
}
