import com.HttpRequest;
import java.io.File;
public class Crawler {

	public Crawler() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args){
		//��ȡurl
		String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2030%202015%2022:52:02%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		//�������
		String filepath="qwq.html";
		//�õ��ļ�
		HttpRequest file=HttpRequest.get(url).header("Cookie","JSESSIONID=AAC0742ECA0EE2B83B26571B0434D3A6.tomcat2");
		//������ļ�
		file.receive(new File(filepath));
	}
	
}
