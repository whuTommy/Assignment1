package test;
import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;

public class crawler {
	
	public static void main(String[] args)
	{
		String urlString = "http://210.42.121.241/servlet/GenImg";
		HttpRequest f = HttpRequest.get(urlString);
		
		f.header("cookies","JSESSIONID=3E768D1733C81A6C21929C7424B718C8.tomcat2");
	
		String fileName = "marks.png";
		
		f.receive(new File(fileName));  
	}

}
