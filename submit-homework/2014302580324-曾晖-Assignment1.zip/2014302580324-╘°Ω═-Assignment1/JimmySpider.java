package jimmyJava;
import java.io.File;

//������ϵͳ2014302580324���ͳɼ�ҳ��
public class JimmySpider
{
	public static void main (String[] args)
	{ 
		//�趨Ҫ��ȡҳ���URL
		String url ="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2029%202015%2018:20:53%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		//�趨Ҫ��ȡҳ���Cookie
		HttpRequest request = HttpRequest.get(url).header("Cookie","JSESSIONID=274B091784CE74AFC11DD7B9DE42604C.tomcat2");
		//����HTML�ĵ�	
		String text="JimmySpider.html";
		request.receive(new File(text));
	}

}
