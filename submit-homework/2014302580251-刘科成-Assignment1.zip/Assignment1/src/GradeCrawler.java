import java.io.File;

import HttpRequest.HttpRequest;

public class GradeCrawler {
	
	public static void main(String args[]){
		String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sat%20Sep%2026%202015%2014:52:07%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		HttpRequest response = HttpRequest.get(url).header("Cookie","JSESSIONID=EFA23856A168153F78AA8440F62938B0.tomcat2");
		String fileName = "Grade.html";
		response.receive(new File(fileName));
	}
	
}
