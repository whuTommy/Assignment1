import java.io.File;

public class RequireLZHScoreList {
	public static void main(String[] args) {

	String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2018:40:25%20GMT+0800%20(CST)";
	String cookie = "JSESSIONID=770B16B067C25192FA2278AD66395280.tomcat2";

	HttpRequest hr = HttpRequest.get(url).header("Cookie", cookie);
	File out = new File("ScoreList.html");
	hr.receive(out);
}	
}