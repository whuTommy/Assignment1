import java.io.IOException;
//import java.io.InputStream;
import java.io.FileOutputStream;
import java.net.URL;
//import java.net.URLConnection;
//import java.util.*;

public class newant {

	public static void main(String args[]) throws IOException
	{
		String urlname = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
		String file = "C:\\Users\\SilverCrux\\Desktop\\test.txt";
		URL path = new URL(urlname);
		FileOutputStream out = new FileOutputStream(file);
		HttpRequest a = new HttpRequest(path,"POST");
		a.header("Cookie","JSESSIONID=D90891DEAC9D6D27FAF2B9887281F6B3.tomcat2");
	    a.receive(out);
	    out.close();
	}
}
