import java.io.File;
public class liuliwei {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url="Http://210.42.121.132/servlet/Svlt_QueryStuScore?";
		HttpRequest request=HttpRequest.get(url).header("Cookie","JSESSIONID=BDB63D5E41D76E80B019BFA8636F4856.tomcat2");
		File a=new File("/a.html");
		request.receive(a);
	
	}

}
