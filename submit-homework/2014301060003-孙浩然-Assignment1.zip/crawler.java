import java.io.File;

public class crawler {
	public static void main(String[] args)
	{
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2028%202015%2017:04:47%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		
		HttpRequest marks = HttpRequest.get(url);
		
		marks.header("cookie","JSESSIONID=6B26B8698B5022EEDF81D91361FED383.tomcat2");
		
		if(marks.ok())
		{
			marks.receive(new File("mine.html")); 
		}
	}

}
