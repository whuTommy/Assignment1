package ʵ��һ;

import java.io.File;
import java.net.HttpCookie;

public class Crawler {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Thu%20Sep%2024%202015%2022:51:39%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		HttpRequest httpRequest=HttpRequest.get(url);
		httpRequest.header("Cookie","JSESSIONID=51F78C9135E8187B17A8C8B309CA9E0C.tomcat2");
		//
		String myHtml="mine.html";
		if (httpRequest.ok()) {
			httpRequest.receive(new File(myHtml));
		}
		
		System.out.println("ִ����ϣ�");
		
	}

}

