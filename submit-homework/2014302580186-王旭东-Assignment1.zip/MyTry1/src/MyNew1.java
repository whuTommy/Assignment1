import java.awt.Component;

import javax.swing.JFrame;
import javax.swing.JOpotionpane;


public class MyNew1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String input=JOpotionpane.showInPutDialog("Enter 1 to draw retangles\n"+"Enter 2 to draw ovals");
int choice =Integer.parseInt(input);
Shapes panel=new Shapes(choice);
JFrame application=new JFrame();
application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

application.setSize(300,300);
application.setVisible(true);
	}

}
