
public class Shapes {

	public Shapes(int choice) {
		// TODO Auto-generated constructor stub
	}

}
