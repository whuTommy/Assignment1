package javax.swing;

import java.io.File;


public class Asment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String MyLessonUrl ="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2027%202015%2021:28:30%20GMT+0800";
		//�洢�ı���URL
		String File="test.html";
		//�洢�ı���URL
		HttpRequest req=HttpRequest.get(MyLessonUrl);
		//GET������ȡ��Ϣ
		req.header("Cookie","JSESSIONID=5978EBB50617F551D5A85487E48EFB35.tomcat2");
		req.receive(new File(File));
	}

}
