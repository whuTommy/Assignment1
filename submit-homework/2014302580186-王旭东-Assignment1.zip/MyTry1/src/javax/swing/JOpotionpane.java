package javax.swing;

public class JOpotionpane {

	public static String showInPutDialog(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
