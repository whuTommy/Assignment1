import java.io.File;
public class Assignment1 
{
	public static void main(String[] args)
	{
		String url="http://210.42.121.134/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2028%202015%2016:32:15%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";		//�ɼ�����ַ	
		
		
			HttpRequest response = HttpRequest.get(url).header("Cookie","JSESSIONID=2974328E1BB4DABE428FB577862E845E.tomcat2");
			//����HttpRequest�Դ��Ĵ��ݵķ�������Cookie	
			if(response.ok())
					{
						response.receive(new File("�ɼ���.html"));
					}
		
	}
}
