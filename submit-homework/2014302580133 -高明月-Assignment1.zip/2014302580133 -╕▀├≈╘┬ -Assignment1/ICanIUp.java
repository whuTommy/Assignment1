import java.io.File;

public class ICanIUp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String url="http://210.42.121.133/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2023%2023:32:02%20UTC+0800%202015";
		String Cookie="7750D3B6850AE779609E78F07814714A.tomcat2";
		HttpRequest response=HttpRequest.get(url);
		response.header("Cookie","JSESSIONID=7750D3B6850AE779609E78F07814714A.tomcat2");
		String fName = "E:/img/grade.html";
		
		response.receive(new File(fName));
		if(response.ok())
		{
			System.out.println("ok");
		}
	}

}
