import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;


public class MyCrawler {
	public static void main(String[] args){
		/*
		 * �������ϵͳ��ַ
		 */
		String urlString = "http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType";
		String filePath="StuScore.html";
		/*
		 * ץȡ�������ϵͳ��ַ
		 */
		HttpRequest response = HttpRequest.get(urlString).header("cookie","JSESSIONID=48AF281D7723D63492636CC4F305D500.tomcat2; _5t_trace_sid=e0bbb95e657254f0ca8af4a63f62eaec; _5t_trace_tms=1");
		File f =  new File(filePath);
		response.receive(f);
	}

}
