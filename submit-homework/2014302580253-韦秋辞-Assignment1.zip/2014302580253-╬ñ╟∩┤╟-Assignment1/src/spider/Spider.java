package spider;

import java.io.File;

public class Spider {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String urlStr="http://210.42.121.133/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
		String htmlPath="mygrade.html";

		HttpRequest response = HttpRequest.get(urlStr);  
		response.header("cookie","JSESSIONID=FC49A2795C4D8E6AE80CB8859613412B.tomcat2");
	    response.receive(new File(htmlPath));
		}
}

	


