package liqian;

import java.io.File;

public class WebpageCrawler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url="http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term="
				+ "&learnType=&scoreFlag=0&t=Sat%20Sep%2026%202015%2016:29:37%20GMT"
				+ "+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";               //�ɼ�����URL
		HttpRequest response=HttpRequest.get(url);                                
		String cookie="JSESSIONID=92C427BD91165E50B8B11B35CE8CA409.tomcat2";      //��½��cookie
		response.header("cookie",cookie);                                         //��cookie�ӵ�header��,ģ���½
		String fName="ScoreWebpage.html";                                         
		if(response.ok()){
			response.receive(new File(fName));
			System.out.println("OK");
		}
	}

}
