import java.io.File;

public class CreateImage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2023%202015%2013:16:17%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
	int imgcounter=1;//�������˼���
      do{
		HttpRequest imgresponse=HttpRequest.get(url);//���÷�װ����
		imgresponse.header("Cookie","JSESSIONID=C7077EC561BC39A8395F3B30DCD95B1E.tomcat2");
		String fName="MyGradeImge"+Integer.toString(imgcounter)+".html";
		if(imgresponse.ok()){
			imgresponse.receive(new File(fName));
			imgcounter++;
		}
      }while(imgcounter<=10);
     System.out.println("ok");
     
	}

}
