import com.github.kevinsawicki.http.HttpRequest;
import java.io.File;

public class MySpider{
	public static void main(String[] args){
		String whuURL = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2027%202015%2018:03:30%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		HttpRequest request = HttpRequest.get(whuURL).header("Cookie","JSESSIONID=58C0986C9D1DDA6EC63E1B6A678EB523.tomcat2");
		String FileName="Score.htm";
		request.receive(new File(FileName));
	}
}