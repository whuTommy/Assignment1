/*
*
* Author: Archibald 
*
* Last modified: 2015-09-20 14:58
*
* Filename: GetScore.java
*
* Description: Web crawler
*
*/

package com.archibald.assignment1;

import java.io.File;

public class GetScore {
	
	static int getPages() {
		//set cookie location 
		String cookie ="JSESSIONID=249CEC03D7791084E1D21A6AFBB652C3.tomcat2";
		
		//define html's location/name
		String html = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2014:24:58%20GMT+0800";
		String htmlName = "ScoreForms/html/score.html";
		
		//get html page
		HttpRequest resp = new HttpRequest(html, "GET");
		resp.getConnection().setRequestProperty("Cookie", cookie);
		//In order to avoid errors
		if(resp.ok()){
		    resp.receive(new File(htmlName));		
		}else{
			return -1;
		}
	    //get css files
	    String cssStyle = "http://210.42.121.241/css/style.css?v=2.002";
	    String cssStyleN = "ScoreForms/css/style.css";
	    resp = new HttpRequest(cssStyle, "GET");
		if(resp.ok()){
			resp.receive(new File(cssStyleN));
		}else{
			return -1;
		}
		String cssTab = "http://210.42.121.241/css/tab.css?v=2.002";
		String cssTabN = "ScoreForms/css/tab.css";
		resp = new HttpRequest(cssTab, "GET");
		if(resp.ok()){
			resp.receive(new File(cssTabN));
		}else{
			return -1;
		}
	    //get javascript files
		String jquery = "http://210.42.121.241/js/jquery.tools.min.js";
		String jqueryN = "ScoreForms/js/jquery.tools.min.js";
		resp = new HttpRequest(jquery, "GET");
		if(resp.ok()){
			resp.receive(new File(jqueryN));
		}else{
			return -1;
		}
		String jtable = "http://210.42.121.241/js/table.js?v=2.002";
		String jtableN = "ScoreForms/js/table.js";
		resp = new HttpRequest(jtable, "GET");
		if(resp.ok()){
			resp.receive(new File(jtableN));
		}else{
			return -1;
		}
		return 0;
	}

	public static void main(String[] args){
		
		 if( -1 == getPages()){
			 System.out.println("Failed");
		 }else{
			 //print succeed if there are no errors
			 System.out.println("Succeed");
		 }
	}
}
