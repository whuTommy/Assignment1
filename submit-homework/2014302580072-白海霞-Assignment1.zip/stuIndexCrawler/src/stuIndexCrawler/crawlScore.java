package stuIndexCrawler;

import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;


public class crawlScore {
public static void main (String[] args){
	//��ȡ��ַ��cookie
	 String urlString = "http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType";
	 String filePath = "myScore.html";
	 
	 for(int i = 0;i <= 10;i++){

	 HttpRequest response = HttpRequest.get(urlString).header("Cookie","JSESSIONID=CF51C99397DBA915AC773A4775D7EA0E.tomcat2");
	 //��������гɼ���html�ļ�
	 response.receive(new File(filePath));
	 //�����Ƿ��ܳɹ����
	 if(response.ok()){
		 System.out.println("ok");
	 }
	 }
}
}
