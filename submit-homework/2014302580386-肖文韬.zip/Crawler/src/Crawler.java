import java.io.File;


/**
 * @author xiaowentao
 *
 */
public class Crawler {

	public static void main(String args[])
	{
		//��ȡ�ɼ�����URL��cookie
		String scoreurl = "http://210.42.121.241//servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%27Sep%2027%202015%2003:30:50%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		String Cookie = "JSESSIONID=CFA8A478F24063ECD3AD32CF93642639.tomcat2";
		//����get����
		HttpRequest response = HttpRequest.get(scoreurl);
		
		response.header("Cookie",Cookie);
		//������ȡ���
		String fName = "myScore.html";
		if(response.ok()){
			response.receive(new File(fName));
			}
	}

}
