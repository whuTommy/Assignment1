/**
 * Created by fuxiuyin on 15-9-24.
 */

public class Main
{

    public static void main(String[] args)
    {
        Jwpc jwpc = new Jwpc();
        jwpc.getClasses();
    }


}
