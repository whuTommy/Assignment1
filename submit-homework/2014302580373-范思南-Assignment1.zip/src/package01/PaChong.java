package package01;

import java.io.File;

public class PaChong {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		String mainUrl = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2023%202015%2011:53:02%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		String cookie = "JSESSIONID=8E67C008FFE492FE79BBEC29E8742F48.tomcat2";
		String myGradeName = "D:/Java/workspace/OOP-JAVA-TEST01/myGrade/myGrade.html";
		
		HttpRequest mainResponse = HttpRequest.get(mainUrl);
		mainResponse.header("Cookie", cookie);
		mainResponse.receive(new File(myGradeName));
		System.out.println("Main is ok");
		
		
		String styleCss = "http://210.42.121.241/css/style.css?v=2.002";
		String style_boyCss = "http://210.42.121.241/css/style_boy.css?v=2.002";
		String style_commonCss = "http://210.42.121.241/css/style_common.css?v=2.002";
		String tabCss = "http://210.42.121.241/css/tab.css?v=2.002";
		
		HttpRequest styleCssResponse = HttpRequest.get(styleCss);
		styleCssResponse.receive(new File("D:/Java/workspace/OOP-JAVA-TEST01/css/style.css"));
		System.out.println("Style is ok");
		
		HttpRequest style_boyCssResponse = HttpRequest.get(style_boyCss);
		style_boyCssResponse.receive(new File("D:/Java/workspace/OOP-JAVA-TEST01/css/style_boy.css"));
		System.out.println("Style_boy is ok");

		HttpRequest style_commonCssResponse = HttpRequest.get(style_commonCss);
		style_commonCssResponse.receive(new File("D:/Java/workspace/OOP-JAVA-TEST01/css/style_common.css"));
		System.out.println("Style_common is ok");
		
		HttpRequest tabCssResponse = HttpRequest.get(tabCss);
		tabCssResponse.receive(new File("D:/Java/workspace/OOP-JAVA-TEST01/css/tab.css"));
		System.out.println("Tab is ok");
		
		
	
	}

}
