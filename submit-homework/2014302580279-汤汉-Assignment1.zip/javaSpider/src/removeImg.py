import os
import Image

for imgFile in os.listdir("."):
	if imgFile.endswith(".png"):
		os.remove(imgFile)