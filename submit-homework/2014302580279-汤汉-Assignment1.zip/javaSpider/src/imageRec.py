#-*- encoding:utf-8 -*-
import Image
import os
import sys

#二值化
def denoise(img):
	img = img.convert("RGBA")
	pixdata = img.load()

	#二值化
	for y in xrange(img.size[1]):
		for x in xrange(img.size[0]):
			if pixdata[x,y][0] < 90:
				pixdata[x,y] = (0,0,0,255)
			if pixdata[x,y][1]< 136:
				pixdata[x,y] = (0,0,0,255)
			if pixdata[x,y][2] > 0:
				pixdata[x,y] = (255,255,255,255)
	return img

#去噪点
def removeNoise(img):
	pix = img.load()
	ls = []
	nest = []
	for x in xrange(img.size[0]):
		for y in xrange(img.size[1]):
			if(x == 0 or x == img.size[0]-1 or y == 0 or y == img.size[1] -1):
				pix[x,y] = (255,255,255,255)
			if (pix[x,y] == (0,0,0,255)):
				nest.append(1)
			else:
				nest.append(0)
		ls.append(nest)
		nest = []

	for x in xrange(1,img.size[0]):
		for y in xrange(1,img.size[1]):
			if(x == 0 or x == img.size[0]-1 or y == 0 or y == img.size[1] -1):
				ls[x][y] = 0
			if(ls[x][y] == 1):
				count = 0
				for m in xrange(x-1,x+2):
					for n in xrange(y-1,y+2):
						if(ls[m][n] == 1):
							count += 1
				if(count < 4):
					ls[x][y] = 0
				count = 0	
	for x in xrange(1,img.size[0]):
		for y in xrange(1,img.size[1]):
			if ls[x][y] == 0:
				pix[x,y] = (255,255,255,255)	
	return img
#获取切割点
def CutPoint(img):
	img = denoise(img)
	img = removeNoise(img)
	pix = img.load()
	ls = []
	nest = []
	for x in xrange(img.size[0]):
		for y in xrange(img.size[1]):
			if(x == 0 or x == img.size[0]-1 or y == 0 or y == img.size[1] -1):
				pix[x,y] = (255,255,255,255)
			if (pix[x,y] == (0,0,0,255)):
				nest.append(1)
			else:
				nest.append(0)
		ls.append(nest)
		nest = []		


	xPos = []
	for x in xrange(img.size[0]):
		for y in xrange(img.size[1]):
			if (ls[x][y] == 1 ):
				if x!=0:
					if xPos.count(x) == 0:
						xPos.append(x)

	xCutPos = []
	xCutPos.append(xPos[0])
	for i in range(0,len(xPos)-1):
		if ((xPos[i] - xPos[i+1]) != -1):
			xCutPos.append(xPos[i])
			xCutPos.append(xPos[i+1])
	xCutPos.append(xPos[len(xPos)-1])

	yCutPos = []
	
	for i in xrange(0,len(xCutPos),2):	
		yPos = []
		for y in xrange(img.size[1]):
			for x in xrange(xCutPos[i],xCutPos[i+1]):
				if ls[x][y] == 1:
					if yPos.count(y) == 0:
						yPos.append(y)
		yPos.sort()
		if(yPos):
			yCutPos.append(yPos[0])
			yCutPos.append(yPos[len(yPos)-1])
	cutPos = []
	cutPos.append(xCutPos)
	cutPos.append(yCutPos)
	return cutPos	


#字膜匹配
result = "./"
#for imgFile in os.listdir("."):
#	if imgFile.endswith(".png"):
#源码路径
sourcePath = os.getcwd()
#转换到上级目录
os.chdir("./..")
#获取上级目录
abovePath = os.getcwd()
#装换到源码目录
os.chdir(sourcePath)
#加载验证码照片
img = Image.open("captcha.jpg")
#灰度二值化去噪
img = denoise(img)
#去噪点
img = removeNoise(img)
#获取分割点
xCutPos = CutPoint(img)[0]
yCutPos = CutPoint(img)[1]
#比对字模库中的图片
os.chdir("./..")
for i in xrange(0,len(xCutPos),2):
	#切割图片
	target = img.crop((xCutPos[i]-1,yCutPos[i]-1,xCutPos[i+1]+2,yCutPos[i+1]+2))
	#统一图片大小
	target = target.resize((20,20))
	#转换到字模目录
	modPath = abovePath+"\\font"
	#转换到字模库
	os.chdir(modPath)
	#防止差异值和字模名
	mods = []
	#循环遍历字模
	for modName in os.listdir(modPath):
		if modName.endswith(".png"):
			#差异值初始化
			diffs = 0
			#加载字模并统一大小
			modImg = Image.open(modName).resize((20,20))
			#字体模板与切割图片的像素值
			modPixel = modImg.load()
			targetPixel = target.load()
			#循环遍历找差异
			for x in xrange(20):
				for y in xrange(20):
					if modPixel[x,y] != targetPixel[x,y]:
						diffs += 1
			#字模照片对应的名
			checkModName = modName[0]
			mods.append((diffs,checkModName))
	#数组排序
	mods.sort()
	#找到最小差异值
	result += mods[0][1]
#转换到源码目录
os.chdir(sourcePath)
#print result
#保存照片
result += ".png"
#os.remove("captcha.jpg")
img.save(result)