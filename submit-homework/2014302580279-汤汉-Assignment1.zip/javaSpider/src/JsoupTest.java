import java.io.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by ziepei on 2015/9/22.
 */
public class JsoupTest {
    private final String userAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";

    public static void main(String[] args) throws IOException, InterruptedException {

        //��ȡ��֤�룬�˹�ʶ������
        URL imgUrl = new URL("http://210.42.121.132/servlet/GenImg");
        HttpRequest imgReq = HttpRequest.get(imgUrl);
        //��ŵ�ַ
        File img = new File("./captcha.jpg");
        imgReq.receive(img);
        String imgCookie = imgReq.header("Set-Cookie");
        String imgSessionId = imgCookie.substring(0, imgCookie.indexOf(";"));
        //������֤��ţ�POST������
        Scanner picScanner = new Scanner(System.in);
        System.out.println("������֤��(��֤��ͼƬ��Ϊcaptcha)��");
        String picData = picScanner.nextLine();
        //������֤��ʶ���ⲿpython���룩���������� �����ύ��˵
        /*String picData = null;
        Process process = Runtime.getRuntime().exec("python imageRec.py");
        File file = new File("./");
        if(file.isDirectory()){
            File[] fs = file.listFiles();
            for(int i=0; i!=fs.length;i++){
                if(fs[i].getName().endsWith(".png")){
                    picData = fs[i].getName().substring(0,fs[i].getName().indexOf("."));
                    System.out.println(picData);
                }
            }
        }*/
        //ʹ��HTTPRequest������ҳ��¼��֤
        Map<String,String> data = new HashMap<String, String>();
        data.put("id","2014302580279");
        data.put("pwd","19940404");
        data.put("xdvfb", picData);
        URL loginUrl = new URL("http://210.42.121.132/servlet/Login");
        //�ύ��ȡ��֤����Ƭ��cookie
        HttpRequest loginReq = HttpRequest.post(loginUrl).header("Cookie",imgSessionId).form(data);
        //�����ض���
        loginReq.followRedirects(false);
        loginReq.body();

        //ץȡ����
        URL gradeUrl = new URL("http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0");
        HttpRequest gradeReq = HttpRequest.post(gradeUrl).header("Cookie",imgSessionId);
        //����ɼ�
        File gradeFile = new File("grade.html");
        if(gradeReq.ok()){
            gradeReq.receive(gradeFile);
        }
        gradeReq.disconnect();
    }
}
