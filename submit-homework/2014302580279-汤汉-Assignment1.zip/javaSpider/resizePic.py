import Image;

img = Image.open("./captcha.jpg");
img = img.resize((50,18));
img.save("./captcha.jpg");