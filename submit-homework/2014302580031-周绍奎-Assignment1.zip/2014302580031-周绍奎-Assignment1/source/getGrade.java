import com.github.kevinsawicki.http.HttpRequest;

import java.io.File;
import java.io.IOException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class getGrade{
    //定义String类型函数getCheckImg获取验证码图片以及cookie并返回
    private static String getCheckImg(String url) throws IOException{
        //创建请求验证码图片的http请求
        HttpRequest checkImgRequest = HttpRequest.get(url);
        //创建一个jpg格式的文件来存储验证码
        File checkImg = new File("./GenImg.jpg");
        //把请求的验证码图片读入上面创建的文件
        checkImgRequest.receive(checkImg);
        //定义cookiePreview来存储http请求返回的header中的Set-Cookie,处理后赋值给cookie变量
        String cookiePreview = checkImgRequest.header("Set-Cookie");
        int end = cookiePreview.indexOf(";");
        String cookie = cookiePreview.substring(0, end);
        checkImgRequest.disconnect();
        return cookie;
    }
    //定义Map类型函数getLoginInfor来读取输入的帐号密码和验证码并传入data中
    private static Map<String, String> getLoginInfor() throws IOException{
        Scanner input = new Scanner(System.in);
        Map<String, String> data = new HashMap<String, String>();
        //输入帐号
        System.out.println("请输入教务系统帐号");
        String id = input.nextLine();
        data.put("id", id);
        //输入密码
        System.out.println("请输入教务系统密码");
        String pwd = input.nextLine();
        data.put("pwd", pwd);
        //输入验证码
        System.out.println("请输入验证码");
        String checkNum = input.nextLine();
        data.put("xdvfb", checkNum);
        input.close();
        return data;
    }
    //最终发送请求获取成绩页面的函数
    public static void sendRequest(String url) throws IOException{
        //调用getCheckImg获取验证码图片以及cookie
        String cookie = getCheckImg("http://210.42.121.133/servlet/GenImg");
        //获取模拟登录需要的表单数据
        Map<String, String> data = getLoginInfor();
        //用之前获取的cookie以及需要的帐号密码验证码等表单数据模拟登录
        HttpRequest loginRequest = HttpRequest.post(url).header("Cookie",cookie).form(data);
        //防止重定向
        loginRequest.followRedirects(false);
        loginRequest.body();

        //发送请求获取成绩页面
        HttpRequest gradeRequest = HttpRequest.post("http://210.42.121.133/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0").header("cookie",cookie);
        //创建文件来存储成绩页面的html代码
        File gradeHtml = new File("./grade.html");
        //如果请求完成就把请求返回的数据写入文件中
        if (gradeRequest.ok()){
            gradeRequest.receive(gradeHtml);
        }

        //最后释放请求链接
        gradeRequest.disconnect();


    }
    public static void main(String[] arg) throws IOException{
        sendRequest("http://210.42.121.133/servlet/Login");
    }
}