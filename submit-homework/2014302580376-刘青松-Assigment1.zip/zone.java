package zuoye;

import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;

public class zone {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
	

				
				String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sat%20Sep%2030%202015%2018:50:18%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
			       
				HttpRequest zuoye = HttpRequest.get(url).header("Cookie","JSESSIONID=D5044376AB36ADB32EA25CD75EFD4EEF.tomcat2; _5t_trace_sid=76f2caa036912b7d08cf0d70da2f491e; _5t_trace_tms=1");
			       
			    zuoye.receive(new File("D:\\test.html"));
			

		}

	}


