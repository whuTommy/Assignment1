package pack2;
import com.HttpRequest;
import java.io.File;

public class Simple {
		public static void main(String[] args){
		//��ȡ����ϵͳ��URL
		String urlString="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2029%202015%2021:45:52%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		//�����ļ����·��
		String filepath="mywork.txt";
		//����cookie
		HttpRequest response=HttpRequest.get(urlString).header("Cookie","JSESSIONID=0FA3AB7D1688828624DA40BC0F7E1F95.tomcat2");
		response.receive(new File(filepath));
		}
}
