import java.io.File;
public class Pachong
{
    public static void main(String[] args)
    {
         
     //����urlString��filePath
         String urlString="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2029%202015%2019:29:58%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
         String filePath="pachong.html";
     //����httpRequest��
         HttpRequest response=HttpRequest.get(urlString);
         response.header("Cookie","JSESSIONID=E8303991A34CC2F9E9BF26FC7AA62C8F.tomcat2");
        
         response.receive(new File(filePath));
        
    }
}