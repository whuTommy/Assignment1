import java.io.File;

/*
@author ������ 2014302580304
*/

public class CoGrade {

	public static void main(String[] args) {
		//url
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
		//��ȡurl
		HttpRequest get =HttpRequest.get(url); 
		//����html�ļ���
		String name = "jcz.html";     
		//��ȡcookie
		get.header("cookie", "JSESSIONID=61EED3DE69AC1106822A392C69456CEA.tomcat2");
		
		if(get.ok()){
			get.receive(new File(name));
		}
	}

}
