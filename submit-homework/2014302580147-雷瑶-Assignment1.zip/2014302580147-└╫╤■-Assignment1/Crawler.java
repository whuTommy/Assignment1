import java.io.File;
import httpRequest.HttpRequest;

public class Crawler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url = "http://210.42.121.134/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2021:09:50%20GMT+0800";
		String cookie = "JSESSIONID=C55C65501E29CF08DA7F8F3F7CA5BF27.tomcat2";
		HttpRequest response = HttpRequest.get(url).header("Cookie",cookie);
		String grade = "MyGrades.html";
		if(response.ok()){
			response.receive(new File(grade));
			System.out.println("ok");
		}	
		
	}
	
}
