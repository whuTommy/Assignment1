/*
 * Program:Crawler mine grades from the website.
 * Author:HuXijie
 * Date:2015.9.21
 */
import java.io.File;

public class GradesCrawler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String myCookie = "JSESSIONID=29BA4FACECC52CF5209AEC5FE3298D16.tomcat2";
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnTyp";
		HttpRequest response =HttpRequest.get(url);
		response.header("Cookie",myCookie);
		String fName = "score.html";
		response.receive(new File(fName));
	}

}
