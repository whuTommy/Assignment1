import java.io.File;

public class GetImage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Wed%20Sep%2030%202015%2023:24:43%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
	
   
		HttpRequest response=HttpRequest.get(url);//���÷�װ����
		response.header("Cookie","JSESSIONID=AA1F024B8080C779EAB666F2AEE0C1CC.tomcat2");
		if(response.ok())
		{
		     String fName="MyGradeImge.html";
		     response.receive(new File(fName));
		}   
	}
}